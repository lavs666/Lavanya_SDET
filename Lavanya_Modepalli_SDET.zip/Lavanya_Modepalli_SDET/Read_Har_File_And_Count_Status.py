import json


def parse_har_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        har_data = json.load(file)
    return har_data

def display_status_code_count(har_parser):
    entries = har_parser['log']
    entries = entries['entries']
    total_status_codes = len(entries)
    count_2xx = count_4xx = count_5xx = 0
    for entry in entries:
        status_code = entry['response']['status']
        if 200 <= status_code < 300:
            count_2xx += 1
        elif 400 <= status_code < 500:
            count_4xx += 1
        elif 500 <= status_code < 600:
            count_5xx += 1

    print(f'Total Status Codes: {total_status_codes}')
    print(f'Total 2XX Status Codes: {count_2xx}')
    print(f'Total 4XX Status Codes: {count_4xx}')
    print(f'Total 5XX Status Codes: {count_5xx}')


har_file_path = 'exactspace.co.har'
har_parser = parse_har_file(har_file_path)
display_status_code_count(har_parser)
